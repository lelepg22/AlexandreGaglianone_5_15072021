class Vue {
  constructor(imageUrl, name) {
    this.imageUrl = imageUrl;
    this.name = name;
  }
}
class getItem {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}
const getIt = new getItem();



function createCard(product) {
  var html = `<div class='col-12 col-lg-5 col-xl-3 mx-5 mt-5 shadow '>
                   <div class='card text-center cardstyling mx-sm-4 produitLink'> 
                    <img src="${product.imageUrl}" alt="${product.name}"  class='card-img-top mx-sm-0   cardimg'>
                      <div class='card-body'>  
                        <h5 class='card-title  mx-sm-1'>${product.name} </h5> 
                          <p class='card-text mx-sm-1'>Teddies </p> 
                            <a href='#' class=' btn btn-primary ml-5 stretched-link mx-sm-1 produitlink\'>Voir plus</a> 
                             
                        </div> 
                        <i class="fas fa-cart-plus cartplus mx-sm-3"></i> 
                    </div> 
                </div> `;
  return html;
}
//let getPath = path[2].children[1].children[0].textContent;

async function listCard() {
  let products = await getAllTeddies();
  for (let product of products) {
    document
      .getElementById("produitList")
      .insertAdjacentHTML("afterbegin", createCard(product));
  }
}
listCard();

 function btnCardList() {
  var btnAddCartList = document.getElementsByClassName("cartplus");
  console.log(btnAddCartList.length);
   for(var i = 0; i < btnAddCartList.length; i++){
    btnAddCartList.item[i].addEventListener('click', () => {
      console.log('fhhc');
      console.log(btnAddCartList[i]);
     });    
   }
  //  btnAddCartList.forEach(btnAddCart => { 
  //   btnAddCart.addEventListener('click', () =>{ console.log(btnAddCart)

  //   } );
     
  //  });
 }
 btnCardList();

// async function addToMyCart(params) {
//   myCart.push(params.path[2].children[1].children[0].textContent);
//     console.log('ici' , myCart);
//     console.log(params.path[2].children[1].children[0].textContent);
// }
// async function addToMyStorage(params) {
//   myStorage.push(params.path[2].children[1].children[0].textContent);
//     console.log(myStorage);
//     console.log(params.path[2].children[1].children[0].textContent);
// }


// function eventListenerMyCart(event) {
//   getCart.addEventListener("click", addToMyCart());
//   console.log(event);
// }

// function eventListenerMyStorage(event) {
//   getProduit.addEventListener("click", addToMyStorage);
//   console.log(event);
// }

// eventListenerMyStorage();
// eventListenerMyCart();

//function eventListenerProduitId(event) { getProduit.addEvent}

//produitLink.forEach( [].addEventListener('click', addTo) , console.log());
/* for (let item of produitLink){
 
 item.addEventListener('click', addTo) , console.log(produitLink); 
 
};
*/

// function a() {
//   console.log(produitName), console.log(btnAddCart);
// }
// a();
