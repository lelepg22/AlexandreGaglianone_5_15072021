class Vue {
  constructor(imageUrl, name) {
    this.imageUrl = imageUrl;
    this.name = name;
  }
}
class getItem {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}
const getIt = new getItem();





//let getPath = path[2].children[1].children[0].textContent;



// var btnAddCartList = document.getElementsByClassName("cartplus");

//  function btnCardList() {  
//   // console.log(btnAddCartList.length);
//   //  for(var i = 0; i < btnAddCartList.length; i++){     
//   //   btnAddCartList.item[i].addEventListener('click', () => {
//   //     console.log('fhhc');
//   //     console.log(btnAddCartList[i]);
//   //    });    
//   //  }
//   //  btnAddCartList.forEach(btnAddCart => { 
//   //   btnAddCart.addEventListener('click', () =>{ console.log(btnAddCart)

//   //   } );
     
//   //  });
//  }
//  btnCardList();

// for (let produto of document.querySelectorAll('.cartplus')) { produto.addEventListener("click", addToMyCart())};

// let cartsArray = document.getElementsByClassName('cartplus');
// cartsArray.forEach ( function(elem) {
//   elem.addEventListener("click", addToMyCart);
// })

// function eventListenerMyCart(event) {  
//   getCart.item(1).addEventListener("click", addToMyCart);  console.log(event);


// }

// eventListenerMyCart();

//function eventListenerProduitId(event) { getProduit.addEvent}

//produitLink.forEach( [].addEventListener('click', addTo) , console.log());
/* for (let item of produitLink){
 
 item.addEventListener('click', addTo) , console.log(produitLink); 
 
};
*/

// function a() {
//   console.log(produitName), console.log(btnAddCart);
// }
// a();
